#!/usr/bin/env python

import rospy
import numpy as np
import math
from p3.msg import JointAngles
from p3.srv import Problem1 as KinService
from p3.srv import Problem2 as JacService
from functools import partial
from std_msgs.msg import Float64MultiArray
from std_msgs.msg import MultiArrayLayout
from std_msgs.msg import MultiArrayDimension

class VK:

	def __init__(self):
		# Initialize service called 'vk'
		rospy.Service('vk', JacService, self.callback)

		# Initialize service for calculating FK from problem1


	def callback(self, data):
		# FILL IN: Calculate Jacobian
		zeros = np.zeros((15,))

		# These dimensions should stay the same
		layout = MultiArrayLayout()
		layout.dim = [MultiArrayDimension('height', 3, 15),
		MultiArrayDimension('width', 5, 5)]

		jac = Float64MultiArray(layout, zeros) # FILL IN: Replace zeros with your result

		return jac



if __name__ == "__main__":
	rospy.init_node('vk_service', anonymous=True)
	vk = VK()
	rospy.spin()
