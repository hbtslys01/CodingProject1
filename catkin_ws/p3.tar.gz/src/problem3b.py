#!/usr/bin/env python

import rospy
from std_msgs.msg import Float64
from geometry_msgs.msg import Point
from p3.srv import Problem3a as IKService
from p3.msg import JointAngles

class Wave:

	def __init__(self):
		# connect to IK service

		# init publishers for joint angles

		# subscribe to p3/wave for arm positions
		pass



if __name__ == '__main__':
	wave = Wave()
	rospy.spin()

