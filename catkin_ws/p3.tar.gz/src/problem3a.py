#!/usr/bin/env python

import rospy
import numpy as np
from math import sqrt, atan2, pi, radians, sin, cos, atan
from p3.msg import JointAngles
from p3.srv import Problem3a as IKService
from p3.srv import Problem2 as VKService
from p3.srv import Problem1 as FKService
from functools import partial
from std_msgs.msg import Float64
from geometry_msgs.msg import Point
from geometry_msgs.msg import Pose
from std_msgs.msg import Float64MultiArray


class IK:

	def __init__(self):
		# Initialize service called 'vk'
		pass

	def callback(self, data):
		pass


if __name__ == "__main__":
	rospy.init_node('ik_service')
	ik = IK()
	rospy.spin()
